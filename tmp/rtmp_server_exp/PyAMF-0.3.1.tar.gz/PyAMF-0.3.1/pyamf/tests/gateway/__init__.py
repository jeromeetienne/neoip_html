# Copyright (c) 2007-2008 The PyAMF Project.
# See LICENSE for details.

"""
Unit tests for Remoting gateways.

@author: U{Nick Joyce<mailto:nick@boxdesign.co.uk>}

@since: 0.1.0
"""
