spam = 'eggs'
